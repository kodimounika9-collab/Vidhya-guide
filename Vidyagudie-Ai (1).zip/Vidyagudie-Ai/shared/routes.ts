import { z } from 'zod';
import { insertResumeSchema, insertCareerGuideSchema, insertSkillSchema, resumes, careerGuides, skills } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  resumes: {
    list: {
      method: 'GET' as const,
      path: '/api/resumes' as const,
      responses: {
        200: z.array(z.custom<typeof resumes.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/resumes' as const,
      input: insertResumeSchema,
      responses: {
        201: z.custom<typeof resumes.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/resumes/:id' as const,
      responses: {
        200: z.custom<typeof resumes.$inferSelect>(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized,
      },
    },
    analyze: {
      method: 'POST' as const,
      path: '/api/resumes/analyze' as const,
      input: z.object({ content: z.string() }),
      responses: {
        200: z.object({ analysis: z.any() }), // AI analysis result
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
  },
  career: {
    list: {
      method: 'GET' as const,
      path: '/api/career-guides' as const,
      responses: {
        200: z.array(z.custom<typeof careerGuides.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
    generate: {
      method: 'POST' as const,
      path: '/api/career/generate' as const,
      input: z.object({
        skills: z.array(z.string()),
        interests: z.array(z.string()),
        goals: z.array(z.string()),
      }),
      responses: {
        200: z.custom<typeof careerGuides.$inferSelect>(), // Returns the generated guide
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/career-guides/:id' as const,
      responses: {
        200: z.custom<typeof careerGuides.$inferSelect>(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized,
      },
    },
  },
  skills: {
    list: {
      method: 'GET' as const,
      path: '/api/skills' as const,
      responses: {
        200: z.array(z.custom<typeof skills.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/skills' as const,
      input: insertSkillSchema,
      responses: {
        201: z.custom<typeof skills.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    recommend: {
      method: 'POST' as const,
      path: '/api/skills/recommend' as const,
      input: z.object({
        currentSkills: z.array(z.string()),
        targetRole: z.string(),
      }),
      responses: {
        200: z.object({ recommendations: z.array(z.string()) }),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
