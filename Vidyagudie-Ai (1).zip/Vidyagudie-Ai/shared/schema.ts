import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from "./models/auth";

// Re-export auth models
export * from "./models/auth";
export * from "./models/chat";

// === TABLE DEFINITIONS ===

export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  content: text("content").notNull(), // Raw content or JSON string
  analysis: jsonb("analysis"), // AI analysis result
  createdAt: timestamp("created_at").defaultNow(),
});

export const careerGuides = pgTable("career_guides", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  roadmap: jsonb("roadmap").notNull(), // AI generated roadmap
  createdAt: timestamp("created_at").defaultNow(),
});

export const skills = pgTable("skills", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  category: text("category").notNull(), // e.g., "Technical", "Soft", "Language"
  proficiency: text("proficiency").notNull(), // "Beginner", "Intermediate", "Advanced"
  createdAt: timestamp("created_at").defaultNow(),
});

// === RELATIONS ===
export const resumesRelations = relations(resumes, ({ one }) => ({
  user: one(users, {
    fields: [resumes.userId],
    references: [users.id],
  }),
}));

export const careerGuidesRelations = relations(careerGuides, ({ one }) => ({
  user: one(users, {
    fields: [careerGuides.userId],
    references: [users.id],
  }),
}));

export const skillsRelations = relations(skills, ({ one }) => ({
  user: one(users, {
    fields: [skills.userId],
    references: [users.id],
  }),
}));

// === BASE SCHEMAS ===
export const insertResumeSchema = createInsertSchema(resumes).omit({ id: true, createdAt: true, userId: true });
export const insertCareerGuideSchema = createInsertSchema(careerGuides).omit({ id: true, createdAt: true, userId: true });
export const insertSkillSchema = createInsertSchema(skills).omit({ id: true, createdAt: true, userId: true });

// === EXPLICIT API CONTRACT TYPES ===

export type Resume = typeof resumes.$inferSelect;
export type InsertResume = z.infer<typeof insertResumeSchema>;

export type CareerGuide = typeof careerGuides.$inferSelect;
export type InsertCareerGuide = z.infer<typeof insertCareerGuideSchema>;

export type Skill = typeof skills.$inferSelect;
export type InsertSkill = z.infer<typeof insertSkillSchema>;

// Request types
export type CreateResumeRequest = InsertResume;
export type AnalyzeResumeRequest = { content: string };
export type GenerateCareerPathRequest = { skills: string[]; interests: string[]; goals: string[] };
export type CreateSkillRequest = InsertSkill;

// Response types
export type ResumeResponse = Resume;
export type CareerGuideResponse = CareerGuide;
export type SkillResponse = Skill;
