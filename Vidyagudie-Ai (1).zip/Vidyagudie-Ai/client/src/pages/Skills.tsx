import { useState } from "react";
import { useSkills, useCreateSkill, useRecommendSkills } from "@/hooks/use-skills";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Loader2, BrainCircuit, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Skills() {
  const { data: skills, isLoading } = useSkills();
  const createSkill = useCreateSkill();
  const recommend = useRecommendSkills();
  const { toast } = useToast();

  // Add Skill State
  const [newSkill, setNewSkill] = useState({ name: "", category: "Technical", proficiency: "Beginner" });
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Recommendations State
  const [targetRole, setTargetRole] = useState("");
  const [recommendations, setRecommendations] = useState<string[]>([]);

  const handleAddSkill = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createSkill.mutateAsync(newSkill);
      setIsDialogOpen(false);
      setNewSkill({ name: "", category: "Technical", proficiency: "Beginner" });
      toast({ title: "Skill Added", description: `${newSkill.name} added successfully.` });
    } catch (error) {
      toast({ title: "Error", description: "Failed to add skill.", variant: "destructive" });
    }
  };

  const handleGetRecommendations = async () => {
    if (!targetRole) return;
    try {
      const currentSkillNames = skills?.map(s => s.name) || [];
      const result = await recommend.mutateAsync({ currentSkills: currentSkillNames, targetRole });
      setRecommendations(result.recommendations);
      toast({ title: "Recommendations Ready", description: "AI has analyzed your skill gaps." });
    } catch (error) {
      toast({ title: "Error", description: "Failed to get recommendations.", variant: "destructive" });
    }
  };

  if (isLoading) return <div className="p-8"><Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" /></div>;

  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader 
        title="Skills & Gaps" 
        description="Manage your skill portfolio and identify gaps for your dream role."
        action={
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" /> Add Skill
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Skill</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddSkill} className="space-y-4 mt-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Skill Name</label>
                  <Input 
                    value={newSkill.name}
                    onChange={e => setNewSkill(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g. React"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Category</label>
                    <Select 
                      value={newSkill.category} 
                      onValueChange={v => setNewSkill(prev => ({ ...prev, category: v }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Technical">Technical</SelectItem>
                        <SelectItem value="Soft">Soft Skill</SelectItem>
                        <SelectItem value="Language">Language</SelectItem>
                        <SelectItem value="Tool">Tool</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Proficiency</label>
                    <Select 
                      value={newSkill.proficiency} 
                      onValueChange={v => setNewSkill(prev => ({ ...prev, proficiency: v }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Beginner">Beginner</SelectItem>
                        <SelectItem value="Intermediate">Intermediate</SelectItem>
                        <SelectItem value="Advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button type="submit" className="w-full" disabled={createSkill.isPending}>
                  {createSkill.isPending ? "Adding..." : "Add Skill"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Skills List */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-xl font-bold font-display mb-4">Your Portfolio</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {skills?.map((skill) => (
              <div key={skill.id} className="p-4 rounded-xl border bg-card hover:border-primary/50 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold">{skill.name}</h3>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${
                    skill.proficiency === 'Advanced' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' :
                    skill.proficiency === 'Intermediate' ? 'bg-blue-50 text-blue-600 border-blue-200' :
                    'bg-yellow-50 text-yellow-600 border-yellow-200'
                  }`}>
                    {skill.proficiency}
                  </span>
                </div>
                <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                  {skill.category}
                </span>
              </div>
            ))}
            {skills?.length === 0 && (
              <div className="col-span-full py-12 text-center text-muted-foreground bg-muted/20 rounded-xl">
                No skills added yet.
              </div>
            )}
          </div>
        </div>

        {/* AI Recommendations */}
        <div className="lg:col-span-1">
          <div className="rounded-2xl bg-gradient-to-br from-primary/5 to-accent/5 border border-primary/10 p-6">
            <div className="flex items-center gap-2 mb-4 text-primary">
              <BrainCircuit className="h-6 w-6" />
              <h2 className="text-lg font-bold font-display">AI Recommendations</h2>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Enter a target job role to see what skills you are missing.
            </p>
            <div className="flex gap-2 mb-6">
              <Input 
                placeholder="e.g. Senior Frontend Dev" 
                value={targetRole}
                onChange={e => setTargetRole(e.target.value)}
                className="bg-background"
              />
              <Button onClick={handleGetRecommendations} disabled={recommend.isPending} size="icon">
                {recommend.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              </Button>
            </div>

            {recommendations.length > 0 && (
              <div className="space-y-3">
                <h3 className="font-semibold text-sm">Recommended to learn:</h3>
                {recommendations.map((rec, i) => (
                  <div key={i} className="flex items-center gap-2 p-3 rounded-lg bg-background border border-primary/20 shadow-sm animate-in fade-in slide-in-from-bottom-2" style={{ animationDelay: `${i * 100}ms` }}>
                    <div className="h-2 w-2 rounded-full bg-accent" />
                    <span className="text-sm font-medium">{rec}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
