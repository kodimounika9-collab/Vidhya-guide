import { Link } from "wouter";
import { ArrowRight, CheckCircle2, Sparkles } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navbar */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold font-display">V</span>
            </div>
            <span className="text-xl font-bold font-display tracking-tight">
              Vidyagudie<span className="text-primary">AI</span>
            </span>
          </div>
          <Link href="/api/login" className="font-medium text-sm px-4 py-2 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 transition-colors">
            Get Started
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-20 pb-32 overflow-hidden relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-primary/5 rounded-full blur-3xl -z-10" />
        <div className="container mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/10 text-accent text-sm font-medium mb-8">
            <Sparkles className="h-4 w-4" />
            <span>AI-Powered Career Guidance</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold font-display tracking-tight mb-6 text-balance">
            Your Personal AI <br />
            <span className="gradient-text">Career Architect</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 text-balance">
            Build ATS-friendly resumes, discover your ideal career path, and get personalized skill recommendations powered by advanced AI.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link 
              href="/api/login"
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-primary text-primary-foreground font-semibold text-lg hover:shadow-lg hover:shadow-primary/25 transition-all hover:-translate-y-1 flex items-center justify-center gap-2"
            >
              Start Building Now
              <ArrowRight className="h-5 w-5" />
            </Link>
            <a 
              href="#features"
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-secondary text-secondary-foreground font-semibold text-lg hover:bg-secondary/80 transition-all"
            >
              Learn More
            </a>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">Everything you need to succeed</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Our AI analyzes your profile to provide tailored guidance every step of the way.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="bg-background p-8 rounded-2xl border shadow-sm hover:shadow-md transition-all">
              <div className="h-12 w-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center mb-6">
                <FileText className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold font-display mb-3">Smart Resume Builder</h3>
              <p className="text-muted-foreground">
                Create professional resumes with AI suggestions. Get instant feedback on content, keywords, and formatting.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-background p-8 rounded-2xl border shadow-sm hover:shadow-md transition-all">
              <div className="h-12 w-12 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center mb-6">
                <Briefcase className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold font-display mb-3">Career Roadmap</h3>
              <p className="text-muted-foreground">
                Define your goals and get a step-by-step roadmap. Our AI identifies the best path for your unique skills.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-background p-8 rounded-2xl border shadow-sm hover:shadow-md transition-all">
              <div className="h-12 w-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mb-6">
                <Lightbulb className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold font-display mb-3">Skill Gap Analysis</h3>
              <p className="text-muted-foreground">
                Identify missing skills for your dream role. Get personalized recommendations on what to learn next.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="bg-primary rounded-3xl p-8 md:p-12 text-center text-primary-foreground relative overflow-hidden">
            <div className="relative z-10 max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold font-display mb-6">Ready to accelerate your career?</h2>
              <p className="text-primary-foreground/80 text-lg mb-8">
                Join thousands of students and professionals using VidyagudieAI to land their dream jobs.
              </p>
              <Link 
                href="/api/login"
                className="inline-flex px-8 py-4 rounded-xl bg-background text-foreground font-bold text-lg hover:bg-white/90 transition-all"
              >
                Get Started for Free
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-background border-t py-12">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p>&copy; 2024 VidyagudieAI. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

function FileText(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg> }
function Briefcase(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="14" x="2" y="7" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg> }
function Lightbulb(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-1 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/></svg> }
