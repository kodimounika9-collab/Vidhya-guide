import { useState } from "react";
import { useResumes, useCreateResume, useAnalyzeResume } from "@/hooks/use-resumes";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { FileText, Loader2, Sparkles, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import ReactMarkdown from "react-markdown";

export default function ResumeBuilder() {
  const { data: resumes, isLoading } = useResumes();
  const createResume = useCreateResume();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({ title: "", content: "" });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createResume.mutateAsync(formData);
      setIsDialogOpen(false);
      setFormData({ title: "", content: "" });
      toast({ title: "Success", description: "Resume created successfully." });
    } catch (error) {
      toast({ title: "Error", description: "Failed to create resume.", variant: "destructive" });
    }
  };

  if (isLoading) return <div className="p-8"><Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" /></div>;

  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader 
        title="Resume Builder" 
        description="Create and analyze your resumes with AI assistance."
        action={
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="lg" className="gap-2">
                <FileText className="h-4 w-4" /> Create New Resume
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-xl">
              <DialogHeader>
                <DialogTitle>Create New Resume</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Resume Title</label>
                  <Input 
                    placeholder="e.g. Software Engineer 2024" 
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Resume Content (Markdown/Text)</label>
                  <Textarea 
                    placeholder="Paste your resume content here..." 
                    className="h-64"
                    value={formData.content}
                    onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                    required
                  />
                </div>
                <div className="flex justify-end pt-4">
                  <Button type="submit" disabled={createResume.isPending}>
                    {createResume.isPending ? "Creating..." : "Save Resume"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {resumes?.map((resume) => (
          <ResumeCard key={resume.id} resume={resume} />
        ))}
        {resumes?.length === 0 && (
          <div className="col-span-full text-center py-12 border-2 border-dashed rounded-xl">
            <p className="text-muted-foreground">No resumes yet. Create your first one to get started!</p>
          </div>
        )}
      </div>
    </div>
  );
}

function ResumeCard({ resume }: { resume: any }) {
  const analyze = useAnalyzeResume();
  const { toast } = useToast();
  const [analysis, setAnalysis] = useState<any>(resume.analysis);

  const handleAnalyze = async () => {
    try {
      const result = await analyze.mutateAsync({ content: resume.content });
      setAnalysis(result.analysis);
      toast({ title: "Analysis Complete", description: "AI has analyzed your resume." });
    } catch (error) {
      toast({ title: "Error", description: "Analysis failed.", variant: "destructive" });
    }
  };

  return (
    <div className="bg-card border rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow flex flex-col h-full">
      <div className="flex items-start justify-between mb-4">
        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
          <FileText className="h-6 w-6" />
        </div>
        <span className="text-xs text-muted-foreground font-medium">
          {new Date(resume.createdAt).toLocaleDateString()}
        </span>
      </div>
      <h3 className="text-lg font-bold font-display mb-2">{resume.title}</h3>
      <p className="text-sm text-muted-foreground line-clamp-3 mb-6 flex-grow">
        {resume.content.substring(0, 150)}...
      </p>
      
      {analysis ? (
        <div className="mt-auto pt-4 border-t">
          <div className="flex items-center gap-2 text-emerald-600 font-medium text-sm mb-2">
            <CheckCircle className="h-4 w-4" /> AI Analyzed
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full">View Analysis</Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>AI Resume Analysis</DialogTitle>
              </DialogHeader>
              <div className="prose prose-sm dark:prose-invert mt-4">
                <ReactMarkdown>{JSON.stringify(analysis, null, 2)}</ReactMarkdown>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      ) : (
        <div className="mt-auto pt-4 border-t">
          <Button 
            onClick={handleAnalyze} 
            disabled={analyze.isPending}
            variant="outline" 
            className="w-full gap-2 border-primary/20 hover:bg-primary/5 hover:text-primary"
          >
            {analyze.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            Analyze with AI
          </Button>
        </div>
      )}
    </div>
  );
}
