import { useState } from "react";
import { useCareerGuides, useGenerateCareerPath } from "@/hooks/use-career";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Briefcase, Loader2, Target, Zap, TrendingUp, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import ReactMarkdown from "react-markdown";

export default function CareerPath() {
  const { data: guides, isLoading } = useCareerGuides();
  const generate = useGenerateCareerPath();
  const { toast } = useToast();

  // Simple form state for generation
  const [skills, setSkills] = useState("");
  const [interests, setInterests] = useState("");
  const [goals, setGoals] = useState("");

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await generate.mutateAsync({
        skills: skills.split(",").map(s => s.trim()),
        interests: interests.split(",").map(s => s.trim()),
        goals: goals.split(",").map(s => s.trim()),
      });
      toast({ title: "Success", description: "Career roadmap generated!" });
      setSkills("");
      setInterests("");
      setGoals("");
    } catch (error) {
      toast({ title: "Error", description: "Failed to generate roadmap.", variant: "destructive" });
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader 
        title="Career Roadmap" 
        description="Discover your ideal career path based on your unique profile."
      />

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Generator Form */}
        <div className="lg:col-span-1">
          <Card className="border-primary/20 shadow-lg shadow-primary/5">
            <CardHeader className="bg-primary/5 border-b border-primary/10">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Sparkles className="h-5 w-5 text-primary" />
                Generate New Path
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <form onSubmit={handleGenerate} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Zap className="h-4 w-4 text-accent" /> Skills (comma separated)
                  </label>
                  <Input 
                    placeholder="React, Python, Communication..." 
                    value={skills}
                    onChange={e => setSkills(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Target className="h-4 w-4 text-accent" /> Interests
                  </label>
                  <Input 
                    placeholder="AI, Web Dev, Design..." 
                    value={interests}
                    onChange={e => setInterests(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-accent" /> Career Goals
                  </label>
                  <Input 
                    placeholder="Become a Senior Dev..." 
                    value={goals}
                    onChange={e => setGoals(e.target.value)}
                    required
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity"
                  disabled={generate.isPending}
                >
                  {generate.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" /> Generating...
                    </>
                  ) : (
                    "Generate AI Roadmap"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Results List */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-2xl font-bold font-display">Your Roadmaps</h2>
          {isLoading ? (
            <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin" /></div>
          ) : guides?.length === 0 ? (
            <div className="text-center py-12 border rounded-xl bg-muted/30">
              <p className="text-muted-foreground">No roadmaps yet. Generate one to get started!</p>
            </div>
          ) : (
            guides?.map((guide) => (
              <Card key={guide.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <CardHeader className="bg-muted/30 pb-4">
                  <CardTitle className="flex justify-between items-center">
                    <span>{guide.title}</span>
                    <span className="text-xs font-normal text-muted-foreground bg-background px-3 py-1 rounded-full border">
                      {new Date(guide.createdAt!).toLocaleDateString()}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6 prose prose-sm dark:prose-invert max-w-none">
                  {/* The roadmap is stored as JSON, but for simplicity assuming string or simple object structure for now */}
                  <div className="bg-accent/5 p-4 rounded-lg border border-accent/10">
                    <ReactMarkdown>
                      {typeof guide.roadmap === 'string' ? guide.roadmap : JSON.stringify(guide.roadmap, null, 2)}
                    </ReactMarkdown>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function Sparkles(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M9 3v4"/><path d="M3 5h4"/><path d="M3 9h4"/></svg> }
