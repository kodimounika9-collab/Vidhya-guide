import { useResumes } from "@/hooks/use-resumes";
import { useSkills } from "@/hooks/use-skills";
import { useCareerGuides } from "@/hooks/use-career";
import { useAuth } from "@/hooks/use-auth";
import { StatsCard } from "@/components/StatsCard";
import { PageHeader } from "@/components/PageHeader";
import { FileText, Lightbulb, Briefcase, ArrowUpRight, Plus } from "lucide-react";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: resumes, isLoading: resumesLoading } = useResumes();
  const { data: skills, isLoading: skillsLoading } = useSkills();
  const { data: guides, isLoading: guidesLoading } = useCareerGuides();

  const isLoading = resumesLoading || skillsLoading || guidesLoading;

  if (isLoading) {
    return <DashboardSkeleton />;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader 
        title={`Welcome back, ${user?.firstName || 'Student'}`}
        description="Here's an overview of your career progress."
      />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <StatsCard 
          title="Total Resumes" 
          value={resumes?.length || 0} 
          icon={<FileText className="h-6 w-6" />}
          trend="Ready to apply"
        />
        <StatsCard 
          title="Skills Tracked" 
          value={skills?.length || 0} 
          icon={<Lightbulb className="h-6 w-6" />}
          trend="Keep growing"
        />
        <StatsCard 
          title="Career Roadmaps" 
          value={guides?.length || 0} 
          icon={<Briefcase className="h-6 w-6" />}
          trend="Paths defined"
        />
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Recent Resumes */}
        <div className="bg-card rounded-xl border p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold font-display">Recent Resumes</h3>
            <Link href="/resumes" className="text-sm font-medium text-primary hover:underline flex items-center gap-1">
              View All <ArrowUpRight className="h-4 w-4" />
            </Link>
          </div>
          
          {resumes && resumes.length > 0 ? (
            <div className="space-y-4">
              {resumes.slice(0, 3).map(resume => (
                <div key={resume.id} className="flex items-center justify-between p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded bg-blue-100 text-blue-600 flex items-center justify-center">
                      <FileText className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="font-semibold">{resume.title}</p>
                      <p className="text-xs text-muted-foreground">Last updated {new Date(resume.createdAt!).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <Link href={`/resumes/${resume.id}`} className="p-2 text-muted-foreground hover:text-primary">
                    <ArrowUpRight className="h-5 w-5" />
                  </Link>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">No resumes created yet.</p>
              <Link href="/resumes" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium">
                <Plus className="h-4 w-4" /> Create Resume
              </Link>
            </div>
          )}
        </div>

        {/* Skills Overview */}
        <div className="bg-card rounded-xl border p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold font-display">Your Top Skills</h3>
            <Link href="/skills" className="text-sm font-medium text-primary hover:underline flex items-center gap-1">
              Manage Skills <ArrowUpRight className="h-4 w-4" />
            </Link>
          </div>

          {skills && skills.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {skills.slice(0, 8).map(skill => (
                <span 
                  key={skill.id} 
                  className="px-3 py-1.5 rounded-full bg-accent/10 text-accent font-medium text-sm border border-accent/20"
                >
                  {skill.name}
                </span>
              ))}
              {skills.length > 8 && (
                <span className="px-3 py-1.5 rounded-full bg-muted text-muted-foreground font-medium text-sm">
                  +{skills.length - 8} more
                </span>
              )}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">Add skills to get recommendations.</p>
              <Link href="/skills" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium">
                <Plus className="h-4 w-4" /> Add Skill
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <Skeleton className="h-12 w-1/3" />
      <div className="grid grid-cols-3 gap-6">
        <Skeleton className="h-32" />
        <Skeleton className="h-32" />
        <Skeleton className="h-32" />
      </div>
    </div>
  );
}
