import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertSkill } from "@shared/routes";

export function useSkills() {
  return useQuery({
    queryKey: [api.skills.list.path],
    queryFn: async () => {
      const res = await fetch(api.skills.list.path, { credentials: "include" });
      if (res.status === 401) throw new Error("Unauthorized");
      if (!res.ok) throw new Error("Failed to fetch skills");
      return api.skills.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateSkill() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertSkill) => {
      const res = await fetch(api.skills.create.path, {
        method: api.skills.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to add skill");
      return api.skills.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.skills.list.path] }),
  });
}

export function useRecommendSkills() {
  return useMutation({
    mutationFn: async (data: { currentSkills: string[]; targetRole: string }) => {
      const res = await fetch(api.skills.recommend.path, {
        method: api.skills.recommend.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to get recommendations");
      return api.skills.recommend.responses[200].parse(await res.json());
    },
  });
}
