import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";

export function useCareerGuides() {
  return useQuery({
    queryKey: [api.career.list.path],
    queryFn: async () => {
      const res = await fetch(api.career.list.path, { credentials: "include" });
      if (res.status === 401) throw new Error("Unauthorized");
      if (!res.ok) throw new Error("Failed to fetch career guides");
      return api.career.list.responses[200].parse(await res.json());
    },
  });
}

export function useGenerateCareerPath() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: { skills: string[]; interests: string[]; goals: string[] }) => {
      const res = await fetch(api.career.generate.path, {
        method: api.career.generate.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to generate career path");
      return api.career.generate.responses[200].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.career.list.path] }),
  });
}

export function useCareerGuide(id: number) {
  return useQuery({
    queryKey: [api.career.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.career.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch career guide");
      return api.career.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}
