## Packages
framer-motion | Complex animations and transitions
recharts | Visualizing career path data and skill gaps
lucide-react | Beautiful icons
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes
react-markdown | Rendering markdown content from AI responses

## Notes
- Theme: Professional Blue/White/Gray with vibrant accents for AI features.
- Font: 'Outfit' for headings, 'Inter' for body text.
- Auth: Uses @/hooks/use-auth for Replit Auth integration.
- API: Hooks in @/hooks/use-resumes.ts, @/hooks/use-career.ts, @/hooks/use-skills.ts.
- Images: Unsplash images used for landing page visuals.
