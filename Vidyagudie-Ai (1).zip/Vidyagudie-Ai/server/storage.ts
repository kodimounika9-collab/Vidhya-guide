import { db } from "./db";
import {
  users, resumes, careerGuides, skills,
  type User, type InsertUser,
  type Resume, type InsertResume,
  type CareerGuide, type InsertCareerGuide,
  type Skill, type InsertSkill
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Resumes
  getResumes(userId: string): Promise<Resume[]>;
  getResume(id: number): Promise<Resume | undefined>;
  createResume(resume: InsertResume): Promise<Resume>;
  updateResumeAnalysis(id: number, analysis: any): Promise<Resume>;

  // Career Guides
  getCareerGuides(userId: string): Promise<CareerGuide[]>;
  getCareerGuide(id: number): Promise<CareerGuide | undefined>;
  createCareerGuide(guide: InsertCareerGuide): Promise<CareerGuide>;

  // Skills
  getSkills(userId: string): Promise<Skill[]>;
  createSkill(skill: InsertSkill): Promise<Skill>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    // Replit Auth uses email or other identifiers, but for compatibility
    const [user] = await db.select().from(users).where(eq(users.email, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Resume methods
  async getResumes(userId: string): Promise<Resume[]> {
    return db.select().from(resumes).where(eq(resumes.userId, userId)).orderBy(desc(resumes.createdAt));
  }

  async getResume(id: number): Promise<Resume | undefined> {
    const [resume] = await db.select().from(resumes).where(eq(resumes.id, id));
    return resume;
  }

  async createResume(insertResume: InsertResume): Promise<Resume> {
    const [resume] = await db.insert(resumes).values(insertResume).returning();
    return resume;
  }

  async updateResumeAnalysis(id: number, analysis: any): Promise<Resume> {
    const [resume] = await db.update(resumes)
      .set({ analysis })
      .where(eq(resumes.id, id))
      .returning();
    return resume;
  }

  // Career Guide methods
  async getCareerGuides(userId: string): Promise<CareerGuide[]> {
    return db.select().from(careerGuides).where(eq(careerGuides.userId, userId)).orderBy(desc(careerGuides.createdAt));
  }

  async getCareerGuide(id: number): Promise<CareerGuide | undefined> {
    const [guide] = await db.select().from(careerGuides).where(eq(careerGuides.id, id));
    return guide;
  }

  async createCareerGuide(insertGuide: InsertCareerGuide): Promise<CareerGuide> {
    const [guide] = await db.insert(careerGuides).values(insertGuide).returning();
    return guide;
  }

  // Skill methods
  async getSkills(userId: string): Promise<Skill[]> {
    return db.select().from(skills).where(eq(skills.userId, userId)).orderBy(desc(skills.createdAt));
  }

  async createSkill(insertSkill: InsertSkill): Promise<Skill> {
    const [skill] = await db.insert(skills).values(insertSkill).returning();
    return skill;
  }
}

export const storage = new DatabaseStorage();
