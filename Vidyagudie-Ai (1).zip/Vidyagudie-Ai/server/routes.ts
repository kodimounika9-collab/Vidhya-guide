import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth } from "./replit_integrations/auth";
import { openai } from "./replit_integrations/audio"; // Reusing the configured openai client

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Replit Auth
  await setupAuth(app);

  // === Resumes ===
  app.get(api.resumes.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    const resumes = await storage.getResumes(userId);
    res.json(resumes);
  });

  app.post(api.resumes.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const userId = (req.user as any).claims.sub;
      const input = api.resumes.create.input.parse({ ...req.body, userId });
      const resume = await storage.createResume(input);
      res.status(201).json(resume);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.message });
      }
      throw err;
    }
  });

  app.get(api.resumes.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const resume = await storage.getResume(parseInt(req.params.id));
    if (!resume) return res.sendStatus(404);
    res.json(resume);
  });

  app.post(api.resumes.analyze.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const { content } = req.body;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          { role: "system", content: "You are an expert resume analyzer. Analyze the following resume content and provide feedback on strengths, weaknesses, and suggestions for improvement. Return the response as JSON." },
          { role: "user", content: content },
        ],
        response_format: { type: "json_object" },
      });

      const analysis = JSON.parse(response.choices[0].message.content || "{}");
      res.json({ analysis });
    } catch (error) {
      console.error("Error analyzing resume:", error);
      res.status(500).json({ message: "Failed to analyze resume" });
    }
  });

  // === Career Guides ===
  app.get(api.career.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    const guides = await storage.getCareerGuides(userId);
    res.json(guides);
  });

  app.post(api.career.generate.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const userId = (req.user as any).claims.sub;
      const { skills, interests, goals } = req.body;

      const prompt = `
        Generate a career roadmap based on the following:
        Skills: ${skills.join(", ")}
        Interests: ${interests.join(", ")}
        Goals: ${goals.join(", ")}
        
        Provide a JSON response with a "title" and a "roadmap" array containing steps (title, description, timeline).
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          { role: "system", content: "You are a career guidance counselor." },
          { role: "user", content: prompt },
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      
      const guide = await storage.createCareerGuide({
        userId,
        title: result.title || "Career Roadmap",
        roadmap: result.roadmap || [],
      });

      res.json(guide);
    } catch (error) {
      console.error("Error generating career guide:", error);
      res.status(500).json({ message: "Failed to generate career guide" });
    }
  });

  app.get(api.career.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const guide = await storage.getCareerGuide(parseInt(req.params.id));
    if (!guide) return res.sendStatus(404);
    res.json(guide);
  });

  // === Skills ===
  app.get(api.skills.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    const userSkills = await storage.getSkills(userId);
    res.json(userSkills);
  });

  app.post(api.skills.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const userId = (req.user as any).claims.sub;
      const input = api.skills.create.input.parse({ ...req.body, userId });
      const skill = await storage.createSkill(input);
      res.status(201).json(skill);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.message });
      }
      throw err;
    }
  });

  app.post(api.skills.recommend.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const { currentSkills, targetRole } = req.body;

    try {
      const prompt = `
        I have the following skills: ${currentSkills.join(", ")}.
        I want to become a: ${targetRole}.
        Recommend 5 skills I should learn next. Return as a JSON object with a "recommendations" array of strings.
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          { role: "system", content: "You are a skill recommendation engine." },
          { role: "user", content: prompt },
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      res.json(result);
    } catch (error) {
      console.error("Error recommending skills:", error);
      res.status(500).json({ message: "Failed to recommend skills" });
    }
  });

  return httpServer;
}
